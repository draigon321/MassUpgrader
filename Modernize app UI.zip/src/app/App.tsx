import { useMemo, useState, useRef } from "react";
import {
  Upload,
  Download,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Layers,
  ArrowUpDown,
  FileCode2,
  Zap,
  RefreshCw,
  Sun,
  Moon,
  Check,
} from "lucide-react";

// ─── Blueprint toolkit ────────────────────────────────────────────────────────

const BELT_VARIANTS = [
  { family: "belt", tier: 1, label: "Conveyor Belt Mk.1", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorBeltMk1/Build_ConveyorBeltMk1.Build_ConveyorBeltMk1_C" },
  { family: "belt", tier: 2, label: "Conveyor Belt Mk.2", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorBeltMk2/Build_ConveyorBeltMk2.Build_ConveyorBeltMk2_C" },
  { family: "belt", tier: 3, label: "Conveyor Belt Mk.3", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorBeltMk3/Build_ConveyorBeltMk3.Build_ConveyorBeltMk3_C" },
  { family: "belt", tier: 4, label: "Conveyor Belt Mk.4", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorBeltMk4/Build_ConveyorBeltMk4.Build_ConveyorBeltMk4_C" },
  { family: "belt", tier: 5, label: "Conveyor Belt Mk.5", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorBeltMk5/Build_ConveyorBeltMk5.Build_ConveyorBeltMk5_C" },
  { family: "belt", tier: 6, label: "Conveyor Belt Mk.6", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorBeltMk6/Build_ConveyorBeltMk6.Build_ConveyorBeltMk6_C" },
  { family: "lift", tier: 1, label: "Conveyor Lift Mk.1", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorLiftMk1/Build_ConveyorLiftMk1.Build_ConveyorLiftMk1_C" },
  { family: "lift", tier: 2, label: "Conveyor Lift Mk.2", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorLiftMk2/Build_ConveyorLiftMk2.Build_ConveyorLiftMk2_C" },
  { family: "lift", tier: 3, label: "Conveyor Lift Mk.3", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorLiftMk3/Build_ConveyorLiftMk3.Build_ConveyorLiftMk3_C" },
  { family: "lift", tier: 4, label: "Conveyor Lift Mk.4", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorLiftMk4/Build_ConveyorLiftMk4.Build_ConveyorLiftMk4_C" },
  { family: "lift", tier: 5, label: "Conveyor Lift Mk.5", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorLiftMk5/Build_ConveyorLiftMk5.Build_ConveyorLiftMk5_C" },
  { family: "lift", tier: 6, label: "Conveyor Lift Mk.6", typePath: "/Game/FactoryGame/Buildable/Factory/ConveyorLiftMk6/Build_ConveyorLiftMk6.Build_ConveyorLiftMk6_C" },
];

const CONVEYOR_VARIANT_BY_TYPE_PATH = new Map(BELT_VARIANTS.map((v) => [v.typePath, v]));
const CONVEYOR_RECIPE_BY_TYPE_PATH = new Map(
  BELT_VARIANTS.map((v) => [v.typePath, v.typePath.replace("/Build_", "/Recipe_").replace(".Build_", ".Recipe_")])
);
const CONVEYOR_TIER_OPTIONS = BELT_VARIANTS;

const getConveyorVariant = (typePath: string) => CONVEYOR_VARIANT_BY_TYPE_PATH.get(typePath) ?? null;
const getConveyorRecipePath = (variant: (typeof BELT_VARIANTS)[0] | null) =>
  variant ? (CONVEYOR_RECIPE_BY_TYPE_PATH.get(variant.typePath) ?? "") : "";
const isConveyorBlueprintObject = (obj: any) => Boolean(obj && getConveyorVariant(obj.typePath));
const getBlueprintStem = (fileName: string) => fileName.replace(/\.(sbp|sbpcfg)$/i, "");

const rewriteConveyorObject = (object: any, targetVariant: (typeof BELT_VARIANTS)[0]) => ({
  ...object,
  typePath: targetVariant.typePath,
  properties: {
    ...object.properties,
    ...(object.properties?.mBuiltWithRecipe
      ? { mBuiltWithRecipe: { ...object.properties.mBuiltWithRecipe, value: { ...object.properties.mBuiltWithRecipe.value, pathName: getConveyorRecipePath(targetVariant) } } }
      : {}),
  },
});

const updateBlueprintConveyorGroupTier = (blueprint: any, family: string, fromTier: number, targetTier: number) => {
  const targetVariant = CONVEYOR_TIER_OPTIONS.find((v) => v.family === family && v.tier === targetTier);
  if (!targetVariant) return blueprint;
  return {
    ...blueprint,
    objects: blueprint.objects.map((obj: any) => {
      const current = getConveyorVariant(obj.typePath);
      if (!current || current.family !== family || current.tier !== fromTier) return obj;
      return rewriteConveyorObject(obj, targetVariant);
    }),
  };
};

const groupEditableBlueprintObjects = (blueprint: any) => {
  const groups = new Map<string, any>();
  for (const [index, object] of blueprint.objects.entries()) {
    const variant = getConveyorVariant(object.typePath);
    if (!variant) continue;
    const key = `${variant.family}:${variant.tier}`;
    const current = groups.get(key) ?? { family: variant.family, tier: variant.tier, variant, count: 0, indices: [] };
    current.count += 1;
    current.indices.push(index);
    groups.set(key, current);
  }
  return Array.from(groups.values()).sort((a, b) =>
    a.family === b.family ? a.tier - b.tier : a.family.localeCompare(b.family)
  );
};

const countEditableBlueprintObjects = (blueprint: any) =>
  blueprint.objects.filter(isConveyorBlueprintObject).length;

const createDefaultBlueprintConfig = (description = "") => ({
  configVersion: 5, description,
  color: { r: 1, g: 1, b: 1, a: 1 },
  iconID: 0, referencedIconLibrary: "", iconLibraryType: "",
});

const downloadBlob = (blob: Blob, fileName: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = fileName; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
};

// ─── Demo data ────────────────────────────────────────────────────────────────

const DEMO_BLUEPRINT = {
  name: "Smelter_MK3",
  objects: [
    ...Array(24).fill(null).map(() => ({ typePath: BELT_VARIANTS[3].typePath, properties: {} })),
    ...Array(8).fill(null).map(() => ({ typePath: BELT_VARIANTS[4].typePath, properties: {} })),
    ...Array(12).fill(null).map(() => ({ typePath: BELT_VARIANTS[2].typePath, properties: {} })),
    ...Array(6).fill(null).map(() => ({ typePath: BELT_VARIANTS[8].typePath, properties: {} })),
    ...Array(4).fill(null).map(() => ({ typePath: BELT_VARIANTS[10].typePath, properties: {} })),
    ...Array(16).fill(null).map(() => ({ typePath: "/Game/FactoryGame/Buildable/Factory/Smelter/Build_Smelter.Build_Smelter_C", properties: {} })),
  ],
  config: { description: "Efficient copper smelter array — 24 smelters, Mk.4 belts, Mk.5 output line." },
};

// ─── Theme ────────────────────────────────────────────────────────────────────

const DARK = {
  pageBg: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(245,158,11,0.06) 0%, transparent 60%), #0c0d0f",
  navBg: "rgba(12,13,15,0.95)",
  dropBarBg: "rgba(14,16,19,0.97)",
  statsBarBg: "rgba(12,13,15,0.97)",
  card: "#141619",
  cardAlt: "#0f1013",
  fg: "#e4e0d8",
  fgMuted: "#7a7770",
  fgDim: "#3a3830",
  border: "rgba(245,158,11,0.14)",
  borderSubtle: "rgba(255,255,255,0.05)",
  borderAccent: "rgba(245,158,11,0.1)",
  amber: "#f59e0b",
  amberBg: "rgba(245,158,11,0.1)",
  amberBorder: "rgba(245,158,11,0.25)",
  amberBorderStrong: "rgba(245,158,11,0.45)",
  amberFg: "#0c0d0f",
  green: "#4ade80",
  greenBg: "rgba(34,197,94,0.1)",
  greenBorder: "rgba(34,197,94,0.2)",
  red: "#f87171",
  redBg: "rgba(239,68,68,0.07)",
  redBorder: "rgba(239,68,68,0.2)",
  beltIcon: "#60a5fa",
  beltIconBg: "rgba(59,130,246,0.08)",
  beltIconBorder: "rgba(59,130,246,0.2)",
  liftIcon: "#c084fc",
  liftIconBg: "rgba(168,85,247,0.08)",
  liftIconBorder: "rgba(168,85,247,0.2)",
  selectBg: "#141619",
  selectFg: "#f59e0b",
};

const LIGHT = {
  pageBg: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(180,90,10,0.06) 0%, transparent 60%), #f0ede8",
  navBg: "rgba(240,237,232,0.96)",
  dropBarBg: "rgba(245,242,237,0.98)",
  statsBarBg: "rgba(240,237,232,0.96)",
  card: "#faf8f5",
  cardAlt: "#f0ede6",
  fg: "#1c1a16",
  fgMuted: "#6b6460",
  fgDim: "#b0aa9e",
  border: "rgba(160,110,20,0.18)",
  borderSubtle: "rgba(0,0,0,0.07)",
  borderAccent: "rgba(160,110,20,0.14)",
  amber: "#b45309",
  amberBg: "rgba(180,83,9,0.09)",
  amberBorder: "rgba(180,83,9,0.28)",
  amberBorderStrong: "rgba(180,83,9,0.5)",
  amberFg: "#ffffff",
  green: "#15803d",
  greenBg: "rgba(21,128,61,0.1)",
  greenBorder: "rgba(21,128,61,0.28)",
  red: "#dc2626",
  redBg: "rgba(220,38,38,0.07)",
  redBorder: "rgba(220,38,38,0.22)",
  beltIcon: "#2563eb",
  beltIconBg: "rgba(37,99,235,0.08)",
  beltIconBorder: "rgba(37,99,235,0.22)",
  liftIcon: "#7c3aed",
  liftIconBg: "rgba(124,58,237,0.08)",
  liftIconBorder: "rgba(124,58,237,0.22)",
  selectBg: "#faf8f5",
  selectFg: "#b45309",
};

type Theme = typeof DARK;

// ─── Tier config — shape + label so color is never the sole signal ────────────

const TIER_META: Record<number, { symbol: string; darkBg: string; darkFg: string; darkBorder: string; lightBg: string; lightFg: string; lightBorder: string }> = {
  1: { symbol: "①", darkBg: "rgba(156,163,175,0.12)", darkFg: "#9ca3af", darkBorder: "rgba(156,163,175,0.3)", lightBg: "rgba(100,116,139,0.1)", lightFg: "#475569", lightBorder: "rgba(100,116,139,0.3)" },
  2: { symbol: "②", darkBg: "rgba(132,204,22,0.12)", darkFg: "#a3e635", darkBorder: "rgba(132,204,22,0.3)", lightBg: "rgba(77,124,15,0.1)", lightFg: "#3f6212", lightBorder: "rgba(77,124,15,0.3)" },
  3: { symbol: "③", darkBg: "rgba(34,197,94,0.12)", darkFg: "#4ade80", darkBorder: "rgba(34,197,94,0.3)", lightBg: "rgba(21,128,61,0.1)", lightFg: "#166534", lightBorder: "rgba(21,128,61,0.3)" },
  4: { symbol: "④", darkBg: "rgba(59,130,246,0.12)", darkFg: "#60a5fa", darkBorder: "rgba(59,130,246,0.3)", lightBg: "rgba(37,99,235,0.1)", lightFg: "#1d4ed8", lightBorder: "rgba(37,99,235,0.3)" },
  5: { symbol: "⑤", darkBg: "rgba(168,85,247,0.12)", darkFg: "#c084fc", darkBorder: "rgba(168,85,247,0.3)", lightBg: "rgba(124,58,237,0.1)", lightFg: "#6d28d9", lightBorder: "rgba(124,58,237,0.3)" },
  6: { symbol: "⑥", darkBg: "rgba(245,158,11,0.14)", darkFg: "#fbbf24", darkBorder: "rgba(245,158,11,0.35)", lightBg: "rgba(180,83,9,0.1)", lightFg: "#92400e", lightBorder: "rgba(180,83,9,0.35)" },
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatReadout({ label, value, highlight, t }: { label: string; value: string | number; highlight?: boolean; t: Theme }) {
  return (
    <div className="flex flex-col gap-1 px-4 py-2.5 border-r last:border-r-0" style={{ borderColor: "rgba(245,158,11,0.08)" }}>
      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.58rem", letterSpacing: "0.14em", color: t.fgMuted }} className="uppercase">
        {label}
      </span>
      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "1.2rem", lineHeight: 1, color: highlight ? t.amber : t.fg }}>
        {value}
        {highlight && value !== "—" && Number(value) > 0 && (
          <span style={{ fontSize: "0.6rem", marginLeft: 4, color: t.amber }}>▲</span>
        )}
      </span>
    </div>
  );
}

function TierBadge({ tier, isDark }: { tier: number; isDark: boolean }) {
  const m = TIER_META[tier] ?? TIER_META[1];
  return (
    <span style={{
      fontFamily: "'JetBrains Mono', monospace", fontSize: "0.68rem", fontWeight: 600,
      background: isDark ? m.darkBg : m.lightBg,
      color: isDark ? m.darkFg : m.lightFg,
      border: `1px solid ${isDark ? m.darkBorder : m.lightBorder}`,
      borderRadius: "3px", padding: "2px 7px", letterSpacing: "0.06em",
    }}>
      {m.symbol} MK.{tier}
    </span>
  );
}

// ─── Main component ────────────────────────────────────────────────────────────

export default function App() {
  const [mode, setMode] = useState<"dark" | "light">("dark");
  const isDark = mode === "dark";
  const t = isDark ? DARK : LIGHT;

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [workingBlueprint, setWorkingBlueprint] = useState<any>(null);
  const [sourceBlueprint, setSourceBlueprint] = useState<any>(null);
  const [descriptionDraft, setDescriptionDraft] = useState("");
  const [statusMessage, setStatusMessage] = useState("Select a `.sbp` file to begin.");
  const [errorMessage, setErrorMessage] = useState("");
  const [isParsing, setIsParsing] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const canParse = Boolean(selectedFile);
  const hasBlueprint = Boolean(workingBlueprint);

  const groupedObjects = useMemo(() => {
    if (!workingBlueprint) return [];
    return groupEditableBlueprintObjects(workingBlueprint);
  }, [workingBlueprint]);

  const beltCount = groupedObjects.filter((e) => e.family === "belt").reduce((s, e) => s + e.count, 0);
  const liftCount = groupedObjects.filter((e) => e.family === "lift").reduce((s, e) => s + e.count, 0);

  const changedCount = useMemo(() => {
    if (!workingBlueprint || !sourceBlueprint) return 0;
    return workingBlueprint.objects.filter(
      (obj: any, i: number) => sourceBlueprint.objects[i]?.typePath !== obj.typePath
    ).length;
  }, [sourceBlueprint, workingBlueprint]);

  const handleFileSelection = (file: File | null) => {
    if (!file || !file.name.toLowerCase().endsWith(".sbp")) {
      setSelectedFile(null);
      setErrorMessage("Only `.sbp` files are supported.");
      return;
    }
    setSelectedFile(file);
    setErrorMessage("");
    setStatusMessage("Blueprint file loaded. Ready to parse.");
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = Array.from(e.target.files ?? []).find((f) => f.name.toLowerCase().endsWith(".sbp")) ?? null;
    handleFileSelection(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = Array.from(e.dataTransfer.files).find((f) => f.name.toLowerCase().endsWith(".sbp")) ?? null;
    handleFileSelection(file);
  };

  const handleParse = async () => {
    if (!canParse || !selectedFile) { setErrorMessage("Choose a `.sbp` blueprint file first."); return; }
    setIsParsing(true); setErrorMessage("");
    try {
      const [mainBuffer, parserModule] = await Promise.all([
        selectedFile.arrayBuffer(),
        import("@etothepii/satisfactory-file-parser"),
      ]);
      const { BlueprintConfig, BlueprintConfigWriter, Parser } = parserModule as any;
      const configWriter = new BlueprintConfigWriter();
      BlueprintConfig.Serialize(configWriter, createDefaultBlueprintConfig(descriptionDraft));
      const configBuffer = configWriter.endWriting();
      const parsed = Parser.ParseBlueprintFiles(getBlueprintStem(selectedFile.name), mainBuffer, configBuffer, { throwErrors: true });
      setSourceBlueprint(parsed); setWorkingBlueprint(parsed);
      setDescriptionDraft(parsed.config.description ?? "");
      setStatusMessage(`Loaded "${parsed.name}" — ${countEditableBlueprintObjects(parsed)} conveyor objects editable.`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage(msg); setStatusMessage("Parse failed.");
      setWorkingBlueprint(null); setSourceBlueprint(null);
    } finally { setIsParsing(false); }
  };

  const loadDemoData = () => {
    setWorkingBlueprint(DEMO_BLUEPRINT); setSourceBlueprint(DEMO_BLUEPRINT);
    setDescriptionDraft(DEMO_BLUEPRINT.config.description);
    setSelectedFile(null); setErrorMessage("");
    setStatusMessage(`Demo loaded: "${DEMO_BLUEPRINT.name}" — ${countEditableBlueprintObjects(DEMO_BLUEPRINT)} conveyor objects.`);
  };

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setDescriptionDraft(val);
    setWorkingBlueprint((bp: any) => bp ? { ...bp, config: { ...bp.config, description: val } } : bp);
  };

  const handleTierChange = (family: string, currentTier: number, nextTierValue: string) => {
    const nextTier = Number(nextTierValue);
    setWorkingBlueprint((bp: any) => bp ? updateBlueprintConveyorGroupTier(bp, family, currentTier, nextTier) : bp);
  };

  const handleExport = async () => {
    if (!workingBlueprint) { setErrorMessage("Parse a blueprint before exporting."); return; }
    setIsExporting(true); setErrorMessage("");
    try {
      const parserModule = await import("@etothepii/satisfactory-file-parser");
      const { Parser } = parserModule as any;
      let mainHeader: any = null;
      const mainChunks: any[] = [];
      const { configFileBinary } = Parser.WriteBlueprintFiles(
        workingBlueprint,
        (h: any) => { mainHeader = h; },
        (c: any) => { mainChunks.push(c); }
      );
      if (!mainHeader) throw new Error("Parser did not produce a blueprint header.");
      const stem = `${workingBlueprint.name || "blueprint"}-tiered`;
      downloadBlob(new Blob([mainHeader, ...mainChunks], { type: "application/octet-stream" }), `${stem}.sbp`);
      downloadBlob(new Blob([configFileBinary], { type: "application/octet-stream" }), `${stem}.sbpcfg`);
      setStatusMessage(`Exported ${stem}.sbp + .sbpcfg with ${changedCount} tier edits.`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage(msg); setStatusMessage("Export failed.");
    } finally { setIsExporting(false); }
  };

  const monoSm: React.CSSProperties = { fontFamily: "'JetBrains Mono', monospace", fontSize: "0.62rem" };
  const monoXs: React.CSSProperties = { fontFamily: "'JetBrains Mono', monospace", fontSize: "0.58rem" };
  const condensed: React.CSSProperties = { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.95rem", letterSpacing: "0.06em" };

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: t.pageBg,
        fontFamily: "'DM Sans', system-ui, sans-serif",
        paddingTop: "calc(3.25rem + 3.5rem)",
        paddingBottom: "5.5rem",
        color: t.fg,
      }}
    >
      {/* ─── Sticky top nav ────────────────────────────────────────── */}
      <header
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 border-b"
        style={{ height: "3.25rem", background: t.navBg, backdropFilter: "blur(12px)", borderColor: t.borderAccent }}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-7 h-7 rounded" style={{ background: t.amberBg, border: `1px solid ${t.amberBorder}` }}>
            <Zap size={13} color={t.amber} />
          </div>
          <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: "1.1rem", letterSpacing: "0.08em", color: t.fg }} className="uppercase">
            Mass Upgrader
          </span>
          <span style={{ ...monoSm, background: t.amberBg, color: t.amber, border: `1px solid ${t.amberBorder}`, borderRadius: "3px", padding: "2px 7px" }}>
            SBP EDITOR
          </span>
        </div>

        <div className="flex items-center gap-3">
          <a
            href="https://github.com/etothepii4/satisfactory-file-parser"
            target="_blank" rel="noreferrer"
            style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", color: t.fgMuted }}
            className="hover:opacity-80 transition-opacity hidden md:block"
          >
            etothepii4/satisfactory-file-parser ↗
          </a>

          {/* Dark / Light toggle */}
          <button
            type="button"
            onClick={() => setMode(isDark ? "light" : "dark")}
            aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded transition-all"
            style={{
              fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem",
              background: t.amberBg, color: t.amber,
              border: `1px solid ${t.amberBorder}`,
            }}
          >
            {isDark ? <Sun size={12} /> : <Moon size={12} />}
            <span className="hidden sm:inline">{isDark ? "Light" : "Dark"}</span>
          </button>
        </div>
      </header>

      {/* ─── Sticky drop bar ───────────────────────────────────────── */}
      <div
        className="fixed left-0 right-0 z-40 border-b"
        style={{ top: "3.25rem", height: "3.5rem", background: t.dropBarBg, backdropFilter: "blur(12px)", borderColor: t.borderAccent }}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
      >
        <div
          className="max-w-5xl mx-auto h-full flex items-center gap-4 px-4 md:px-6 transition-all"
          style={{ background: isDragging ? t.amberBg : "transparent" }}
        >
          <label className="flex items-center gap-2.5 cursor-pointer flex-1 min-w-0">
            <input ref={fileInputRef} type="file" accept=".sbp" onChange={handleInputChange} className="hidden" />
            <div
              className="flex items-center justify-center w-7 h-7 rounded shrink-0 transition-colors"
              style={{ background: isDragging ? t.amberBg : "transparent", border: `1px solid ${isDragging ? t.amberBorderStrong : t.amberBorder}` }}
            >
              <Upload size={12} color={t.amber} />
            </div>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.72rem", color: isDragging ? t.amber : selectedFile ? t.fg : t.fgMuted }} className="truncate transition-colors">
              {isDragging ? "Release to load blueprint…" : selectedFile ? selectedFile.name : "Drop `.sbp` file or click to browse"}
            </span>
          </label>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button" onClick={handleParse} disabled={!canParse || isParsing}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, letterSpacing: "0.06em", fontSize: "0.82rem", background: canParse && !isParsing ? t.amber : t.amberBg, color: canParse && !isParsing ? t.amberFg : t.fgMuted }}
            >
              {isParsing ? <RefreshCw size={11} className="animate-spin" /> : <Layers size={11} />}
              {isParsing ? "Parsing…" : "Parse"}
            </button>

            <button
              type="button" onClick={handleExport} disabled={!hasBlueprint || isExporting}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, letterSpacing: "0.06em", fontSize: "0.82rem", background: "transparent", color: hasBlueprint ? t.fg : t.fgDim, border: `1px solid ${hasBlueprint ? t.amberBorder : t.borderSubtle}` }}
            >
              {isExporting ? <RefreshCw size={11} className="animate-spin" /> : <Download size={11} />}
              {isExporting ? "Exporting…" : "Export"}
            </button>

            <button
              type="button" onClick={loadDemoData}
              className="px-3 py-1.5 rounded transition-all"
              style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.65rem", background: "transparent", color: t.fgDim, border: `1px solid ${t.borderSubtle}` }}
            >
              demo
            </button>
          </div>
        </div>
      </div>

      {/* ─── Main content ──────────────────────────────────────────── */}
      <main className="max-w-5xl mx-auto px-4 md:px-6 py-6 grid gap-4 flex-1 w-full">

        {/* Status / error */}
        {(statusMessage || errorMessage) && (
          errorMessage ? (
            <div className="flex items-start gap-2 rounded px-3 py-2.5" style={{ background: t.redBg, border: `1px solid ${t.redBorder}` }}>
              <AlertTriangle size={13} color={t.red} className="mt-0.5 shrink-0" />
              <p style={{ ...monoSm, color: t.red }}>{errorMessage}</p>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <CheckCircle2 size={13} color={t.green} className="shrink-0" />
              <p style={{ ...monoSm, color: t.fgMuted }}>{statusMessage}</p>
            </div>
          )
        )}

        {/* ─── Editor ──────────────────────────────────────────────── */}
        {hasBlueprint ? (
          <>
            {/* Description */}
            <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${t.border}`, background: t.card }}>
              <div className="px-5 py-3 flex items-center gap-2 border-b" style={{ borderColor: t.borderAccent }}>
                <span style={{ ...monoSm, color: t.amber }}>01</span>
                <span style={{ ...condensed, color: t.fg }} className="uppercase">Blueprint Description</span>
                <span style={{ ...monoSm, color: t.fgMuted, marginLeft: "auto" }}>{workingBlueprint.name}</span>
              </div>
              <div className="p-5">
                <textarea
                  rows={3}
                  value={descriptionDraft}
                  onChange={handleDescriptionChange}
                  placeholder="Enter a blueprint description…"
                  className="w-full resize-y rounded px-4 py-3 text-sm focus:outline-none transition-all"
                  style={{ fontFamily: "'DM Sans', sans-serif", background: t.cardAlt, border: `1px solid ${t.borderSubtle}`, color: t.fg, minHeight: 80, caretColor: t.amber }}
                  onFocus={(e) => (e.target.style.borderColor = t.amberBorderStrong)}
                  onBlur={(e) => (e.target.style.borderColor = t.borderSubtle)}
                />
                <p style={{ ...monoXs, color: t.fgDim }} className="mt-1.5">Written into the exported `.sbpcfg` companion file</p>
              </div>
            </div>

            {/* Conveyor groups */}
            <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${t.border}`, background: t.card }}>
              <div className="px-5 py-3 flex items-center gap-3 border-b" style={{ borderColor: t.borderAccent }}>
                <span style={{ ...monoSm, color: t.amber }}>02</span>
                <span style={{ ...condensed, color: t.fg }} className="uppercase">Conveyor Groups</span>
                <span style={{ ...monoSm, color: t.fgMuted, marginLeft: "auto" }}>
                  {groupedObjects.length} group{groupedObjects.length !== 1 ? "s" : ""}
                </span>
              </div>

              <div className="p-4 grid gap-2">
                {groupedObjects.length === 0 ? (
                  <div className="text-center py-10 rounded" style={{ border: `1px dashed ${t.borderSubtle}`, background: t.cardAlt }}>
                    <p style={{ color: t.fgDim }} className="text-sm">No conveyor objects found in this blueprint</p>
                  </div>
                ) : (
                  groupedObjects.map((group) => {
                    const isBelt = group.family === "belt";
                    const familyOptions = CONVEYOR_TIER_OPTIONS.filter((o) => o.family === group.family);
                    return (
                      <div
                        key={`${group.family}-${group.tier}`}
                        className="flex items-center gap-4 rounded px-4 py-3 transition-all"
                        style={{ background: t.cardAlt, border: `1px solid ${t.borderSubtle}` }}
                        onMouseEnter={(e) => ((e.currentTarget as HTMLDivElement).style.borderColor = t.amberBorder)}
                        onMouseLeave={(e) => ((e.currentTarget as HTMLDivElement).style.borderColor = t.borderSubtle)}
                      >
                        {/* Type icon — shape differs for belt vs lift, independent of color */}
                        <div
                          className="flex items-center justify-center w-8 h-8 rounded shrink-0"
                          style={{ background: isBelt ? t.beltIconBg : t.liftIconBg, border: `1px solid ${isBelt ? t.beltIconBorder : t.liftIconBorder}` }}
                          title={isBelt ? "Conveyor Belt" : "Conveyor Lift"}
                        >
                          {isBelt
                            ? <Layers size={13} color={t.beltIcon} />
                            : <ArrowUpDown size={13} color={t.liftIcon} />}
                        </div>

                        {/* Label */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.95rem", color: t.fg }}>
                              {isBelt ? "Conveyor Belt" : "Conveyor Lift"}
                            </span>
                            <TierBadge tier={group.tier} isDark={isDark} />
                          </div>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span style={{ ...monoSm, color: t.fgMuted }}>×</span>
                            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.9rem", color: t.fg }}>{group.count}</span>
                            <span style={{ ...monoSm, color: t.fgMuted }}>&nbsp;objects</span>
                          </div>
                        </div>

                        <ChevronRight size={13} color={t.fgDim} className="shrink-0" />

                        {/* Tier selector */}
                        <div className="flex flex-col gap-1 shrink-0">
                          <span style={{ ...monoXs, color: t.fgMuted, letterSpacing: "0.1em" }} className="uppercase">Target tier</span>
                          <select
                            value={group.tier}
                            onChange={(e) => handleTierChange(group.family, group.tier, e.target.value)}
                            className="rounded px-3 py-1.5 cursor-pointer focus:outline-none transition-all"
                            style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", background: t.selectBg, border: `1px solid ${t.amberBorder}`, color: t.selectFg, minWidth: 170 }}
                            onFocus={(e) => (e.target.style.borderColor = t.amberBorderStrong)}
                            onBlur={(e) => (e.target.style.borderColor = t.amberBorder)}
                          >
                            {familyOptions.map((opt) => (
                              <option key={opt.typePath} value={opt.tier} style={{ background: t.selectBg, color: t.fg }}>
                                {TIER_META[opt.tier]?.symbol} {opt.label}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {changedCount > 0 && (
                <div
                  className="mx-4 mb-4 flex items-center justify-between rounded px-4 py-2.5"
                  style={{ background: t.amberBg, border: `1px solid ${t.amberBorder}` }}
                >
                  <div className="flex items-center gap-2">
                    <Zap size={12} color={t.amber} />
                    <span style={{ ...monoSm, color: t.amber }}>
                      {changedCount} object{changedCount !== 1 ? "s" : ""} modified — ready to export
                    </span>
                  </div>
                  <button
                    type="button" onClick={handleExport} disabled={isExporting}
                    className="flex items-center gap-2 px-4 py-1.5 rounded transition-all disabled:opacity-40"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, letterSpacing: "0.06em", fontSize: "0.85rem", background: t.amber, color: t.amberFg }}
                  >
                    {isExporting ? <RefreshCw size={11} className="animate-spin" /> : <Download size={11} />}
                    Export
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <div
            className="rounded-lg p-8 flex items-center justify-center"
            style={{ border: `1px dashed ${t.borderAccent}`, background: isDark ? "rgba(20,22,25,0.5)" : "rgba(250,248,245,0.5)", minHeight: 140 }}
          >
            <div className="text-center grid gap-2">
              <div className="flex items-center justify-center gap-2" style={{ color: t.fgDim }}>
                <Layers size={16} />
                <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: "0.9rem", letterSpacing: "0.06em" }} className="uppercase">
                  Editor — awaiting blueprint
                </span>
              </div>
              <p style={{ ...monoXs, color: t.fgDim }}>Parse a `.sbp` file or load the demo to begin editing</p>
            </div>
          </div>
        )}
      </main>

      {/* ─── Sticky bottom stats bar ───────────────────────────────── */}
      <div
        className="fixed bottom-0 left-0 right-0 z-50 border-t"
        style={{ background: t.statsBarBg, backdropFilter: "blur(12px)", borderColor: t.borderAccent }}
      >
        <div className="max-w-5xl mx-auto">
          <div className="px-4 md:px-6 py-1.5 flex items-center gap-2 border-b" style={{ borderColor: isDark ? "rgba(245,158,11,0.07)" : "rgba(160,110,20,0.1)" }}>
            <Cpu size={10} color={t.amber} />
            <span style={{ ...monoXs, color: t.fgMuted, letterSpacing: "0.14em" }} className="uppercase">Blueprint status</span>
            {hasBlueprint && (
              <span
                className="flex items-center gap-1"
                style={{ ...monoXs, background: t.greenBg, color: t.green, border: `1px solid ${t.greenBorder}`, borderRadius: "3px", padding: "1px 6px" }}
              >
                <Check size={9} /> LOADED
              </span>
            )}
            <span style={{ ...monoXs, color: t.fgDim }} className="ml-auto hidden sm:block">
              Parsing powered by{" "}
              <a
                href="https://github.com/etothepii4/satisfactory-file-parser"
                target="_blank"
                rel="noreferrer"
                style={{ color: t.fgMuted, textDecoration: "underline", textUnderlineOffset: "2px" }}
              >
                etothepii4/satisfactory-file-parser
              </a>
            </span>
          </div>
          <div className="flex overflow-x-auto px-2 md:px-4" style={{ scrollbarWidth: "none" }}>
            <StatReadout label="File" value={workingBlueprint?.name ?? "—"} t={t} />
            <StatReadout label="Groups" value={groupedObjects.length} t={t} />
            <StatReadout label="Belts" value={beltCount} t={t} />
            <StatReadout label="Lifts" value={liftCount} t={t} />
            <StatReadout label="Objects" value={workingBlueprint?.objects.length ?? "—"} t={t} />
            <StatReadout label="Pending" value={changedCount} highlight={changedCount > 0} t={t} />
          </div>
        </div>
      </div>
    </div>
  );
}
